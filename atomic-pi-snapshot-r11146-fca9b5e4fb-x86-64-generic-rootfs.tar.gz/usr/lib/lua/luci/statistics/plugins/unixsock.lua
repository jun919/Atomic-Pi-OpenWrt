return {
    legend = {
		{ "SocketFile", "SocketGroup", "SocketPerms" },
		{ },
		{ }
	},
	label = _("UnixSock"),
	category = "output"
}
