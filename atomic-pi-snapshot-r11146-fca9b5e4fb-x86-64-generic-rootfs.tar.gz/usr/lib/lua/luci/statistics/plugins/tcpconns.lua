return {
    legend = {
		{ },
		{ "ListeningPorts" },
		{ "LocalPorts", "RemotePorts" }
	},
	label = _("TCP Connections"),
	category = "network"
}
