return {
	legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Interfaces" }
	},
	label = _("Interfaces"),
	category = "network"
}
