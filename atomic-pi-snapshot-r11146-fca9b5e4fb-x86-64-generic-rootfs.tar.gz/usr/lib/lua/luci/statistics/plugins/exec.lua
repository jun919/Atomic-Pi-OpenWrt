return {
	label = _("Exec"),
	category = "general"
}
