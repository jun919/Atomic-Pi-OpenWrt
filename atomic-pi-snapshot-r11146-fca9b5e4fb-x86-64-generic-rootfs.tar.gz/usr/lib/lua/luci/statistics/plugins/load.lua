return {
	legend = {
		{ },
		{ },
		{ }
	},
	label = _("System Load"),
	category = "general"
}
