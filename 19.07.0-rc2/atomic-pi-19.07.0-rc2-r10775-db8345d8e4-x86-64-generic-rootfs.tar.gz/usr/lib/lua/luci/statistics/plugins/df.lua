return {
	legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Devices", "MountPoints", "FSTypes" }
	},
	label = _("Disk Space Usage"),
	category = "general"
}
