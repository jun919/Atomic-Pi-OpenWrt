return {
    legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Sensor" }
	},
	label = _("Sensors"),
	category = "general"
}
