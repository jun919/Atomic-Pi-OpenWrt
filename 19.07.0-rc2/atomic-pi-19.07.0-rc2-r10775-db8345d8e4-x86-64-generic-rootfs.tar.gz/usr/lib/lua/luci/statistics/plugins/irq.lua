return {
	legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Irqs" }
	},
	label = _("Interrupts"),
	category = "general"
}
