return {
	legend = {
		{ },
		{ },
		{ }
	},
	label = _("Conntrack"),
	category = "network"
}
