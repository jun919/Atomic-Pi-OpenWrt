return {
    legend = {
		{ },
		{ },
		{ "Processes" }
	},
	label = _("Processes"),
	category = "general"
}
