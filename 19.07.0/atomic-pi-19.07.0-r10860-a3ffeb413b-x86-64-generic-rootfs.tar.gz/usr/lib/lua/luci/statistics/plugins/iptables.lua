return {
	label = _("Firewall"),
	category = "network"
}
