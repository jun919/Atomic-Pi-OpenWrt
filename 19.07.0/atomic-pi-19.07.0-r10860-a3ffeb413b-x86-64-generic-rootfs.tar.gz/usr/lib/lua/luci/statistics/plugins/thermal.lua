return {
    legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Device" }
	},
	label = _("Thermal"),
	category = "general"
}
