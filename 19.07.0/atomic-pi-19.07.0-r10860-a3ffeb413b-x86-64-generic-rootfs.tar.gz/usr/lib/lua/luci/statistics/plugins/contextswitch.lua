return {
	legend = {
		{ },
		{ },
		{ }
	},
	label = _("Context Switches"),
	category = "general"
}
