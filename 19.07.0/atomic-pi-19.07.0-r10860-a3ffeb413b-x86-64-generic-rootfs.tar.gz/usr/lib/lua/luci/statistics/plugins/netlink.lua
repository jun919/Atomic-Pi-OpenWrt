return {
	legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Interfaces", "VerboseInterfaces", "QDiscs", "Classes", "Filters" }
	},
	label = _("Netlink"),
	category = "network"
}
