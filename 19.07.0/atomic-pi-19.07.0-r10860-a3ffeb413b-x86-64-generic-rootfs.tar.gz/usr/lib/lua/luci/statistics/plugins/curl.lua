return {
	label = _("cUrl"),
	category = "network"
}
