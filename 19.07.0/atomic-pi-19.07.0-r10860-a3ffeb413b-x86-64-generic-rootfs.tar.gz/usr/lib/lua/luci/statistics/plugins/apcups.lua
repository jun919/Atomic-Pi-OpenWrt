return {
	legend = {
		{ "Host", "Port" },
		{ },
		{ }
	},
	label = _("APC UPS"),
	category = "general"
}
