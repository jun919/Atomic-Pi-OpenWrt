return {
    legend = {
		{ },
		{ "CollectIndividualUsers", "CollectUserCount", "CollectCompression", "ImprovedNamingSchema" },
		{ "StatusFile" }
	},
	label = _("OpenVPN"),
	category = "network"
}
