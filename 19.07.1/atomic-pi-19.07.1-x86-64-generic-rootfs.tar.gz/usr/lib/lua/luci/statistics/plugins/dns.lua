return {
	legend = {
		{ },
		{ },
		{ "Interfaces", "IgnoreSources" }
	},
	label = _("DNS"),
	category = "network"
}
