return {
	legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Interfaces" }
	},
	label = _("Wireless"),
	category = "network"
}
