return {
    legend = {
		{ },
		{ },
		{ }
	},
	label = _("Uptime"),
	category = "general"
}
