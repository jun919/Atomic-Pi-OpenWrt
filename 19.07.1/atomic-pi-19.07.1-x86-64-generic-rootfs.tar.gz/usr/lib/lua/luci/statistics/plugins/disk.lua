return {
	legend = {
		{ },
		{ "IgnoreSelected" },
		{ "Disks" }
	},
	label = _("Disk Usage"),
	category = "general"
}
